﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImportGAData
{
    public class Site
    {        
        private string accountId;
        private int id;

        public int siteId
        {
            get { return id; }
            set { id = value; }
        }

        public string account
        {
            get { return accountId; }
            set { accountId = value; }
        }

    }
}
